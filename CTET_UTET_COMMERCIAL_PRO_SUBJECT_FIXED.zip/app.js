let mode="CTET",key="",idx=0,score=0,answered=false;
const COLORS=["#ff006e","#8338ec","#3a86ff","#00b4d8","#06d6a0","#ffbe0b","#fb5607"];
const SUBJECTS=["CDP","Hindi","Sanskrit","English","Math","Science","SST"];

function setMode(m){
 mode=m; key=""; idx=0; score=0;
 document.getElementById("ct").classList.toggle("active",m==="CTET");
 document.getElementById("ut").classList.toggle("active",m==="UTET");
 document.getElementById("choose").textContent=(m==="CTET"?"🇮🇳 CTET — ":"🏔️ UTET — ")+"विषय चुनें";
 drawSubjects();
 document.getElementById("app").innerHTML='<div class="welcome">ऊपर दिखाई दे रहे विषयों में से किसी एक पर क्लिक करें।<br><br>जिस विषय पर क्लिक करेंगे, <b>सिर्फ उसी विषय के 50 प्रश्न</b> शुरू होंगे।</div>';
}
function drawSubjects(){
 const box=document.getElementById("subjects");
 box.innerHTML="";
 SUBJECTS.forEach((s,i)=>{
   const b=document.createElement("button");
   b.className="sub"; b.style.background=COLORS[i];
   b.innerHTML=s+"<span>50 HIGH-LEVEL QUESTIONS</span>";
   b.onclick=()=>start(mode+" • "+s);
   box.appendChild(b);
 });
}
function start(k){key=k;idx=0;score=0;render();}
function render(){
 answered=false; const d=DATA[key][idx], s=key.split(" • ")[1];
 let options=d.o.map((x,i)=>'<button class="opt" onclick="answer('+i+',this)">'+String.fromCharCode(65+i)+'. '+x+'</button>').join("");
 document.getElementById("app").innerHTML='<div class="card"><span class="badge">'+mode+" • "+s+" • "+(idx+1)+'/50</span><div class="q">'+d.q+'</div>'+options+'<div id="concept"></div><div class="controls"><button class="prev" onclick="prev()">⬅ पिछला</button><button class="next" onclick="next()">अगला ➜</button></div><div class="score">Score: '+score+'/50</div></div>';
}
function answer(i,b){
 if(answered)return; answered=true; const d=DATA[key][idx];
 document.querySelectorAll(".opt").forEach((x,n)=>{x.classList.add("disabled");if(n===d.a)x.classList.add("correct");});
 if(i===d.a){score++;b.classList.add("correct");}else b.classList.add("wrong");
 document.getElementById("concept").innerHTML='<div class="concept"><b>'+(i===d.a?"🟢 WELL DONE!":"🔴 WRONG ANSWER")+'</b><br><b>Concept:</b> '+d.e+'</div>';
 document.querySelector(".score").textContent="Score: "+score+"/50";
}
function next(){if(idx<49){idx++;render();}else{document.getElementById("app").innerHTML='<div class="card"><h2>🎉 '+key.split(" • ")[1]+' COMPLETE</h2><div class="score">Final Score: '+score+'/50</div><button class="opt correct" onclick="start(key)">फिर से शुरू करें</button></div>';}}
function prev(){if(idx>0){idx--;render();}}
setMode("CTET");
