CTET UTET MASTER PRO
Files: index.html, style.css, app.js, questions.js.
CTET: 7 subjects x 50 questions. UTET: 7 subjects x 50 Uttarakhand-context questions.
Subject click opens ONLY that subject. Correct answer turns green; wrong answer red; concept appears below.
GitHub Pages: upload files -> Settings -> Pages -> Deploy from branch -> main/root.
